AMINFARDTRAP PRO V2
====================
This is a static website ready for GitHub Pages.

Files:
- index.html
- assets/aminfardtrap-logo.png (the exact logo uploaded by the user)

To publish free:
1. Create a public GitHub repository.
2. Upload index.html and the assets folder.
3. Settings -> Pages -> Deploy from a branch -> main -> /root -> Save.

The player is currently a professional visual/demo player. To make it play real audio,
add MP3 files and connect them to an HTML <audio> element or a streaming service.
